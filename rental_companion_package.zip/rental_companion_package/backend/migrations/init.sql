CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  phone TEXT UNIQUE,
  email TEXT UNIQUE,
  password_hash TEXT,
  role TEXT DEFAULT 'user',
  kyc_status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE companions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  bio TEXT,
  hourly_rate NUMERIC,
  city TEXT,
  verified BOOLEAN DEFAULT false
);
CREATE TABLE bookings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  companion_id INTEGER REFERENCES companions(id),
  start TIMESTAMP,
  end TIMESTAMP,
  status TEXT,
  price NUMERIC,
  created_at TIMESTAMP DEFAULT now()
);
