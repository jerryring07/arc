Rental Companion - Backend scaffold
----------------------------------
This is a minimal Node.js + Express scaffold for the Rental Companion MVP.
Files included:
- src/index.js : app entry
- src/routes/* : example routes (auth, companions, bookings)
- migrations/init.sql : initial schema (Postgres)
Next steps:
- Replace placeholder logic with real DB calls (knex/pg/prisma)
- Configure environment variables for JWT_SECRET, DB connection, Stripe keys
- Implement KYC file upload, payment integration, and webhooks
