const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
// POST /api/auth/signup (simplified - replace DB calls)
router.post('/signup', async (req, res) => {
  const {name, phone, password} = req.body;
  const hash = await bcrypt.hash(password, 10);
  // TODO: save user to DB
  const token = jwt.sign({userId: 1}, process.env.JWT_SECRET || 'devsecret');
  res.json({token});
});
module.exports = router;
