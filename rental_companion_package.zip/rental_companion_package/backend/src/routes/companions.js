const express = require('express');
const router = express.Router();
// GET /api/companions - simple placeholder
router.get('/', async (req, res) => {
  res.json([{id:1,name:'Sample Companion',hourly_rate:1500,city:'Mumbai',rating:4.9}]);
});
module.exports = router;
