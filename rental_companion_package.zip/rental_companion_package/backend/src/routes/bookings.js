const express = require('express');
const router = express.Router();
// POST /api/bookings
router.post('/', async (req, res) => {
  const {userId, companionId, start, end, price} = req.body;
  // TODO: create booking in DB & create payment intent
  res.json({bookingId: 123, status: 'pending'});
});
router.post('/:id/accept', async (req, res) => {
  // TODO: verify companion owns booking
  res.json({status: 'confirmed'});
});
module.exports = router;
