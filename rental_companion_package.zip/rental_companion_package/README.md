Rental Companion — Full package

Contents:
- backend/ : Node.js + Express scaffold with example routes and SQL migrations
- android_app/ : minimal Android Kotlin skeleton files
- wireframes_png/ : placeholder PNG wireframes for main screens
- admin_sop.md : Admin SOP (moderation, refunds, escalation)

Download the zip and open the README files in each folder for next steps.
