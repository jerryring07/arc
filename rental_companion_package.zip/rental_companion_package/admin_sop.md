# Admin SOP — Moderation, Refunds & Emergency Escalation

## 1. Overview
This document outlines standard operating procedures for admin moderators handling KYC approvals, disputes, refunds and emergency incidents.

## 2. KYC & Companion Approval
- All companion applications go into the KYC queue.
- Admin must verify government ID, selfie, and background-check report.
- Approve only if ID matches selfie and background-check clear.
- Record approval reason in audit log.

## 3. Dispute Handling (User Reports)
- Categories: Safety incident, Payment/refund, No-show, Policy violation.
- Triage: Safety incidents -> High priority (response within 2 hours).
- Collect evidence: chat logs, booking details, receipts.
- If needed, freeze payouts and request a statement from companion.

## 4. Refund Policy
- Auto-refund if companion rejects booking before meeting.
- Partial/full refund decisions made after review; document rationale.

## 5. Emergency Escalation
- If companion or user triggers emergency button, admin receives location & booking ID.
- Admin calls emergency contact and offers to contact local authorities if requested.
- Flag companion for immediate review; consider temporary suspension.

## 6. Audit & Compliance
- All admin actions require a brief reason and are logged.
- Retain logs for minimum 2 years (per legal guidance), redact PII where necessary.

## 7. Privacy & Data Handling
- Store KYC docs in secure S3 with restricted access.
- Retain chat logs for 90 days by default, extend for active disputes.

## 8. Contact
- For legal issues, consult the company's legal counsel before public statements.
