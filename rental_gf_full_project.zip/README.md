# Rental GF Full Project (Starter)

Package name: com.sachin.rentalgf

## Structure
- functions/        -> Firebase Cloud Functions (Razorpay integration)
- lib/              -> Flutter app source (main + auth + booking/payment)
- pubspec.yaml      -> Flutter dependencies
- android/...       -> Android manifest (patched)

## Quick setup
1. Place `google-services.json` into `android/app/`.
2. In `functions/` run `npm install`.
3. Set Firebase functions config (use your Razorpay keys):
   ```
   firebase functions:config:set razorpay.key_id="rzp_test_xxx" razorpay.key_secret="xxx" razorpay.webhook_secret="whsec_xxx" app.admin_secret="some_admin_secret"
   ```
4. Deploy functions:
   ```
   firebase deploy --only functions
   ```
5. Run Flutter app:
   ```
   flutter pub get
   flutter run
   ```

## Notes
- Update package name in other Gradle files if you change it.
- Do not commit secrets to source control.
- Use test keys for Razorpay during development.
