// functions/index.js
// Firebase Functions (Node 18) — Callable createOrder, webhook handler, refund & payout examples

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Razorpay = require('razorpay');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');
const axios = require('axios');

admin.initializeApp();
const db = admin.firestore();

// Load Razorpay config from Functions config. Set these using:
// firebase functions:config:set razorpay.key_id="rzp_test_xxx" razorpay.key_secret="xxx" razorpay.webhook_secret="whsec_xxx"
const RZP_KEY_ID = functions.config().razorpay.key_id;
const RZP_KEY_SECRET = functions.config().razorpay.key_secret;
const RZP_WEBHOOK_SECRET = functions.config().razorpay.webhook_secret;

if (!RZP_KEY_ID || !RZP_KEY_SECRET) {
  console.warn('Razorpay config not set. Use firebase functions:config:set razorpay.key_id and key_secret.');
}

const razorpay = new Razorpay({
  key_id: RZP_KEY_ID,
  key_secret: RZP_KEY_SECRET,
});

// Express app to host webhook (raw body required for signature verification)
const app = express();
app.use(cors({ origin: true }));

// Raw body parser for webhook route only
app.post('/razorpayWebhook', bodyParser.raw({ type: '*/*' }), async (req, res) => {
  const signature = req.headers['x-razorpay-signature'];
  const payload = req.body; // raw Buffer

  if (!RZP_WEBHOOK_SECRET) {
    console.error('Webhook secret not configured');
    return res.status(500).send('Webhook not configured');
  }

  // Verify signature
  const expected = crypto.createHmac('sha256', RZP_WEBHOOK_SECRET).update(payload).digest('hex');
  if (signature !== expected) {
    console.warn('Invalid webhook signature');
    return res.status(400).send('Invalid signature');
  }

  let event;
  try {
    event = JSON.parse(payload.toString('utf8'));
  } catch (err) {
    console.error('Failed to parse webhook payload', err);
    return res.status(400).send('Bad payload');
  }

  console.log('Received Razorpay webhook:', event.event);

  try {
    // Handle relevant events
    if (event.event === 'payment.captured' || event.event === 'order.paid') {
      const payment = event.payload.payment ? event.payload.payment.entity : null;
      const order = event.payload.order ? event.payload.order.entity : null;

      // Try to find bookingId from order.receipt
      let bookingId = null;
      if (order && order.receipt) bookingId = order.receipt;
      if (!bookingId && payment && payment.order_id) {
        // find booking by orderId
        const q = await db.collection('bookings').where('orderId', '==', payment.order_id).limit(1).get();
        if (!q.empty) bookingId = q.docs[0].id;
      }

      if (bookingId) {
        await db.collection('bookings').doc(bookingId).update({
          status: 'confirmed',
          paymentId: payment ? payment.id : null,
          paymentDetails: event.payload,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
        console.log('Booking', bookingId, 'marked confirmed');
      } else {
        console.warn('Booking not found for webhook event', event.event);
      }
    } else if (event.event === 'payment.failed') {
      const payment = event.payload.payment.entity;
      if (payment && payment.order_id) {
        const q = await db.collection('bookings').where('orderId', '==', payment.order_id).limit(1).get();
        if (!q.empty) {
          await q.docs[0].ref.update({
            status: 'failed',
            paymentDetails: event.payload,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        }
      }
    }

    // respond 200
    return res.status(200).send('OK');
  } catch (e) {
    console.error('Webhook processing error', e);
    // Return 500 so Razorpay may retry — but be cautious of duplicate handling
    return res.status(500).send('Server error');
  }
});

// Export express app as an HTTP function at path /api
exports.api = functions.https.onRequest(app);

// ------------------------------
// Callable createOrder function
// ------------------------------
// This is a Firebase Callable function you can call from the Flutter client
exports.createOrder = functions.https.onCall(async (data, context) => {
  // Authentication check
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }

  // Validate input
  const clientId = context.auth.uid;
  const companionId = data.companionId;
  const amount = Number(data.amount); // rupees
  const start = data.start || null;
  const end = data.end || null;

  if (!companionId || !amount || amount <= 0) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing or invalid fields');
  }

  // Create booking document with status: created
  const docRef = db.collection('bookings').doc();
  const booking = {
    bookingId: docRef.id,
    clientId: clientId,
    companionId: companionId,
    start: start,
    end: end,
    amount: amount, // rupees
    amountPaise: Math.round(amount * 100),
    currency: 'INR',
    orderId: null,
    paymentId: null,
    status: 'created',
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  };

  await docRef.set(booking);

  // Create Razorpay order
  const options = {
    amount: booking.amountPaise,
    currency: 'INR',
    receipt: booking.bookingId,
    payment_capture: 1 // auto-capture
  };

  try {
    const order = await razorpay.orders.create(options);
    // Update booking with order id and status pending
    await docRef.update({ orderId: order.id, status: 'pending' });

    return {
      success: true,
      orderId: order.id,
      bookingId: booking.bookingId,
      amount: booking.amountPaise,
      currency: 'INR',
      keyId: RZP_KEY_ID,
    };
  } catch (err) {
    console.error('Razorpay order creation failed', err);
    // rollback: set booking to failed
    await docRef.update({ status: 'failed', error: String(err) });
    throw new functions.https.HttpsError('internal', 'Payment initialization failed');
  }
});

// ------------------------------
// Refund example (Admin-only HTTP function)
// ------------------------------
// Use this endpoint from your admin server or Cloud Functions (not from client) to refund a payment.
// Input JSON: { paymentId: 'pay_XXXX', amountPaise: 10000 } (optional amount for partial refund)
exports.refundPayment = functions.https.onRequest(async (req, res) => {
  // Basic auth check (in example) — replace with proper IAM or admin auth
  const ADMIN_SECRET = functions.config().app ? functions.config().app.admin_secret : null;
  const provided = req.headers['x-admin-secret'];
  if (!ADMIN_SECRET || provided !== ADMIN_SECRET) return res.status(403).send('Forbidden');

  try {
    const { paymentId, amountPaise } = req.body;
    if (!paymentId) return res.status(400).send('Missing paymentId');

    const payload = {};
    if (amountPaise) payload.amount = amountPaise; // partial refund

    const refund = await razorpay.payments.refund(paymentId, payload);
    // Optionally update booking/refund record
    return res.status(200).json({ success: true, refund });
  } catch (e) {
    console.error('Refund error', e);
    return res.status(500).json({ error: e.message });
  }
});

// ------------------------------
// Payout example (Razorpay Payouts / Transfers)
// ------------------------------
// Note: To use Razorpay Payouts or Transfers, your account must be enabled and you must follow their KYC.
// This example uses Razorpay's Transfers API to move funds from your Razorpay account to a beneficiary
// (you must have created a contact & fund_account for the beneficiary earlier via Razorpay APIs).

// Expected body: { transfer: { account: 'acc_XXXX', amountPaise: 50000, currency: 'INR', notes: {} } }
exports.createTransfer = functions.https.onRequest(async (req, res) => {
  // Admin check
  const ADMIN_SECRET = functions.config().app ? functions.config().app.admin_secret : null;
  const provided = req.headers['x-admin-secret'];
  if (!ADMIN_SECRET || provided !== ADMIN_SECRET) return res.status(403).send('Forbidden');

  try {
    const { account, amountPaise, notes } = req.body;
    if (!account || !amountPaise) return res.status(400).send('Missing fields');

    // Transfer payload
    const payload = {
      account: account, // beneficiary fund_account id
      amount: amountPaise,
      currency: 'INR',
      notes: notes || {}
    };

    // Razorpay Transfers API — note: SDK may not have direct wrapper; use axios to call REST API
    const auth = Buffer.from(`${RZP_KEY_ID}:${RZP_KEY_SECRET}`).toString('base64');
    const response = await axios.post('https://api.razorpay.com/v1/transfers', payload, {
      headers: {
        Authorization: `Basic ${auth}`,
        'Content-Type': 'application/json'
      }
    });

    return res.status(200).json({ success: true, transfer: response.data });
  } catch (e) {
    console.error('Transfer error', e.response ? e.response.data : e.message);
    const errData = e.response ? e.response.data : { message: e.message };
    return res.status(500).json({ error: errData });
  }
});

// ------------------------------
// Notes on admin endpoints:
// - Secure them via environment secrets (functions config) or better: restrict access via IAM, use callable functions with custom claims or a dedicated admin backend.
// - Do NOT call refundPayment or createTransfer from mobile clients.
