import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'booking_payment.dart';

class AuthGate extends StatefulWidget {
  @override
  _AuthGateState createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _loading = false;

  Future<void> _signInAnonymously() async {
    setState(() => _loading = true);
    try {
      await _auth.signInAnonymously();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sign-in failed: $e')));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: Text('Sign in')),
        body: Center(
          child: _loading
              ? CircularProgressIndicator()
              : ElevatedButton(onPressed: _signInAnonymously, child: Text('Sign in (Demo)')),
        ),
      );
    }

    // Simple home showing booking button
    return Scaffold(
      appBar: AppBar(title: Text('Welcome')),
      body: Center(
        child: ElevatedButton(
          child: Text('Book sample companion (₹500)'),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingPaymentPage(companionId: 'companion_demo', amount: 500))),
        ),
      ),
    );
  }
}
