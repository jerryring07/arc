import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_functions/firebase_functions.dart';

class BookingPaymentPage extends StatefulWidget {
  final String companionId;
  final double amount; // rupees

  BookingPaymentPage({required this.companionId, required this.amount});

  @override
  _BookingPaymentPageState createState() => _BookingPaymentPageState();
}

class _BookingPaymentPageState extends State<BookingPaymentPage> {
  late Razorpay _razorpay;
  bool _loading = false;
  String? bookingId;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _createOrderAndPay() async {
    setState(() => _loading = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Not signed in');

      // Call Firebase Callable Function createOrder
      final callable = FirebaseFunctions.instance.httpsCallable('createOrder');
      final result = await callable.call(<String, dynamic>{
        'companionId': widget.companionId,
        'amount': widget.amount,
        'start': DateTime.now().toIso8601String(),
        'end': DateTime.now().add(Duration(hours: 3)).toIso8601String(),
      });

      final data = result.data as Map<String, dynamic>;
      if (data['success'] != true) throw Exception('Order creation failed');

      final orderId = data['orderId'] as String;
      bookingId = data['bookingId'] as String;
      final amountPaise = data['amount'] as int;
      final keyId = data['keyId'] as String;

      var options = {
        'key': keyId,
        'amount': amountPaise, // paise
        'name': 'Rental Companion',
        'description': 'Booking payment',
        'order_id': orderId,
        'prefill': {
          'contact': user.phoneNumber ?? '',
          'email': user.email ?? ''
        },
        'theme': {'color': '#F37254'}
      };

      _razorpay.open(options);
    } catch (e) {
      print('Error createOrder: $e');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment init failed: $e')));
    } finally {
      setState(() => _loading = false);
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment successful')));
    if (bookingId != null) {
      final ref = FirebaseFirestore.instance.collection('bookings').doc(bookingId);
      await ref.update({
        'paymentId': response.paymentId,
        'status': 'processing', // webhook will set confirmed
        'clientSignature': response.signature,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment failed: ${response.message}')));
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('External wallet: ${response.walletName}')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Book & Pay')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('You are booking companion: ${widget.companionId}'),
            SizedBox(height: 8),
            Text('Amount: ₹${widget.amount.toStringAsFixed(0)}'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loading ? null : _createOrderAndPay,
              child: _loading ? CircularProgressIndicator() : Text('Pay & Confirm'),
            ),
            SizedBox(height: 20),
            if (bookingId != null)
              StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance.collection('bookings').doc(bookingId).snapshots(),
                builder: (context, snap) {
                  if (!snap.hasData) return Text('Waiting for booking...');
                  final doc = snap.data!;
                  final status = doc['status'] ?? '—';
                  return Column(
                    children: [
                      Text('Booking ID: ${doc.id}'),
                      Text('Status: $status'),
                    ],
                  );
                },
              )
          ],
        ),
      ),
    );
  }
}
